import React from 'react';
import PortfolioItem from './PortfolioItem';

const longFormData = [
    {
      imgSrc: 'https://img.youtube.com/vi/CYfmyXesxbs/maxresdefault.jpg',
      title: 'Space Documentary',
      category: 'Long Form Video',
      videoUrl: 'https://www.youtube.com/watch?v=CYfmyXesxbs&list=PLWLaz8VAHjPdz3n-5DcOQPesp2G81CL_c',
    },
    {
      imgSrc: 'https://img.youtube.com/vi/6LKyLtuLPYo/maxresdefault.jpg',
      title: 'Boxing Highlights',
      category: 'Long Form Video',
      videoUrl: 'https://www.youtube.com/watch?v=6LKyLtuLPYo&list=PLWLaz8VAHjPfSoCOJ8tWNlWMoaxE7GKhg',
    },
    {
      imgSrc: 'https://img.youtube.com/vi/iD6Z5aX0_Bo/maxresdefault.jpg',
      title: 'Fashion Showcase',
      category: 'Long Form Video',
      videoUrl: 'https://www.youtube.com/watch?v=iD6Z5aX0_Bo&list=PLWLaz8VAHjPdfDCFPG8j4IZNTvv2AbxqL',
    },
    {
      imgSrc: 'https://img.youtube.com/vi/CNR3rdB6XY4/maxresdefault.jpg',
      title: 'True Crime Story',
      category: 'Long Form Video',
      videoUrl: 'https://www.youtube.com/watch?v=CNR3rdB6XY4&list=PLWLaz8VAHjPfiOe639MzkgolP-sD4nUUQ',
    },
     {
      imgSrc: 'https://img.youtube.com/vi/P-_hyAxwvgE/maxresdefault.jpg',
      title: 'Finance Explained',
      category: 'Long Form Video',
      videoUrl: 'https://www.youtube.com/watch?v=P-_hyAxwvgE&list=PLWLaz8VAHjPfJFZsx4Fpa2cmoB5FW7QnL',
    },
    {
      imgSrc: 'https://img.youtube.com/vi/RskicZW8t6c/maxresdefault.jpg',
      title: 'Crypto Analysis',
      category: 'Long Form Video',
      videoUrl: 'https://www.youtube.com/watch?v=RskicZW8t6c&list=PLWLaz8VAHjPeLL7axjFxO7NJ6VS8L2kH0',
    },
    {
      imgSrc: 'https://img.youtube.com/vi/RPkyzr8KU1M/maxresdefault.jpg',
      title: 'Celebrity News',
      category: 'Long Form Video',
      videoUrl: 'https://www.youtube.com/watch?v=RPkyzr8KU1M&list=PLWLaz8VAHjPcR_p1A-SF7uYUJtt3d_K8z&index=2',
    },
];

const shortsData = [
  {
    imgSrc: 'https://img.youtube.com/vi/JwtTFFb5iZQ/maxresdefault.jpg',
    title: 'Short Clip 1',
    category: 'Short Form',
    videoUrl: 'https://www.youtube.com/watch?v=JwtTFFb5iZQ&list=PLWLaz8VAHjPdN7yZ3I7elcXglPUd_MUiY',
    format: 'short',
  },
  {
    imgSrc: 'https://img.youtube.com/vi/WkOxigen-dg/maxresdefault.jpg',
    title: 'Short Clip 2',
    category: 'Short Form',
    videoUrl: 'https://www.youtube.com/watch?v=WkOxigen-dg&list=PLWLaz8VAHjPdN7yZ3I7elcXglPUd_MUiY&index=4',
    format: 'short',
  },
  {
    imgSrc: 'https://img.youtube.com/vi/wDMvvxq7HLg/maxresdefault.jpg',
    title: 'Short Clip 3',
    category: 'Short Form',
    videoUrl: 'https://www.youtube.com/watch?v=wDMvvxq7HLg&list=PLWLaz8VAHjPdN7yZ3I7elcXglPUd_MUiY&index=5',
    format: 'short',
  },
  {
    imgSrc: 'https://img.youtube.com/vi/ulOItQaqi5s/maxresdefault.jpg',
    title: 'Short Clip 4',
    category: 'Short Form',
    videoUrl: 'https://www.youtube.com/watch?v=ulOItQaqi5s&list=PLWLaz8VAHjPdN7yZ3I7elcXglPUd_MUiY&index=6',
    format: 'short',
  },
  {
    imgSrc: 'https://img.youtube.com/vi/XsTv9r6hIUw/maxresdefault.jpg',
    title: 'Short Clip 5',
    category: 'Short Form',
    videoUrl: 'https://www.youtube.com/watch?v=XsTv9r6hIUw&list=PLWLaz8VAHjPdN7yZ3I7elcXglPUd_MUiY&index=13',
    format: 'short',
  },
];


const Portfolio: React.FC = () => {
  return (
    <section id="portfolio" className="py-20 bg-[#FFF9F9]">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-serif font-bold text-center mb-12 text-gray-900">Latest Work</h2>
        {/* Long Form Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {longFormData.map((item, index) => (
            <PortfolioItem
              key={`long-${index}`}
              imgSrc={item.imgSrc}
              title={item.title}
              category={item.category}
              videoUrl={item.videoUrl}
              format="long"
            />
          ))}
        </div>

        {/* Short Form Content */}
        <h2 className="text-4xl font-serif font-bold text-center mt-20 mb-12 text-gray-900">Short Form Content</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-x-6 gap-y-12">
           {shortsData.map((item, index) => (
            <PortfolioItem
              key={`short-${index}`}
              imgSrc={item.imgSrc}
              title={item.title}
              category={item.category}
              videoUrl={item.videoUrl}
              format="short"
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;