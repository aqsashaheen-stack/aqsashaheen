import React from 'react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="container mx-auto px-6 py-20 md:py-32">
      <div className="flex flex-col md:flex-row items-center">
        {/* Left Column */}
        <div className="md:w-1/2 lg:w-3/5 text-center md:text-left mb-16 md:mb-0">
          <p className="text-lg text-accent font-medium mb-2 tracking-wide">HELLO THERE, NICE TO MEET YOU!</p>
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-gray-900 leading-tight mb-4">
            Aqsa Shaheen
          </h1>
          <p className="text-lg text-gray-600 max-w-lg mx-auto md:mx-0 mb-8">
            I am a professional video editor with a passion for visual storytelling. I thrive on turning raw footage into compelling narratives, bringing a blend of creativity, precision, and dedication to every project.
          </p>
          <a
            href="https://wa.me/923101562323?text=Hello%2C%20I%27d%20like%20to%20discuss%20a%20video%20editing%20project%20with%20you"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-accent text-white font-bold py-3 px-8 rounded-md hover:bg-red-700 transition duration-300 ease-in-out transform hover:scale-105 inline-block"
          >
            Get In Touch
          </a>
        </div>

        {/* Right Column */}
        <div className="md:w-1/2 lg:w-2/5 flex items-center justify-center">
          <div className="relative w-80 h-80 md:w-96 md:h-96">
             <div className="absolute top-0 right-0 w-32 h-32 bg-red-100 rounded-full -z-10 blur-2xl opacity-70"></div>
             <div className="absolute bottom-0 left-0 w-48 h-48 bg-red-50 rounded-full -z-10 blur-2xl opacity-50"></div>
            <div className="w-full h-full rounded-full bg-white p-3 shadow-2xl">
              <img
                src="https://lh3.googleusercontent.com/d/1UUI-boVE95hnNWzQNDrEQdPeHNVhcPsR"
                alt="Aqsa Shaheen, Video Editor"
                className="w-full h-full object-cover rounded-full"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;