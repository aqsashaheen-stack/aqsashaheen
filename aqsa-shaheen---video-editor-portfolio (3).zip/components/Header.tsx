import React, { useState } from 'react';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const href = e.currentTarget.getAttribute('href');
    if (!href) return;

    const targetId = href.substring(1);
    const targetElement = document.getElementById(targetId);

    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
    
    setIsOpen(false);
  };

  const navLinks = [
    { href: '#home', label: 'Home' },
    { href: '#portfolio', label: 'Portfolio' },
    { href: '#services', label: 'Services' },
    { href: '#process', label: 'Process' },
    { href: '#contact', label: 'Contact' },
  ];

  const socialIcons = (
    <>
        <a href="#" aria-label="Twitter" className="text-gray-600 hover:text-accent"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.223.085a4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" /></svg></a>
        <a href="#" aria-label="Vimeo" className="text-gray-600 hover:text-accent"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23.97 6.2c-.22 1.48-1.46 3.93-3.7 7.35-2.27 3.47-4.13 5.2-5.6 5.2-.84 0-1.63-.9-2.36-2.7-.5-1.2-1-2.4-1.5-3.6-.5-1.2-1-2.4-1.5-3.6-.5-1.2-1-2.4-1.5-3.6-.5-1.2-1-2.4-1.5-3.6C5.23 2.9 4.6 1.9 3.78 1.9c-.2 0-.54.3-.9.8l-.93 1.3c-.4.6-.8 1.1-1.2 1.6-.5.6-1.1 1-1.7 1.1-.3 0-.5-.1-.7-.3-.2-.2-.3-.4-.3-.7 0-.4.3-.8.8-1.2.6-.5 1.1-.9 1.4-1.4.4-.5.7-1.1.8-1.8.2-1.1.8-1.9 1.9-2.3C3.5.1 4.5 0 5.6 0c1.7 0 3 1.1 3.9 3.3.9 2.2 1.3 4.1 1.4 5.7.2 1.8.6 3.2 1.2 4.3.8 1.4 1.6 2.1 2.5 2.1.8 0 1.6-.9 2.4-2.6.8-1.8 1.2-3.3 1.2-4.6 0-.9-.1-1.7-.4-2.3-.3-.6-.7-1-1.2-1-.6 0-1.1.3-1.4.8-.4.5-.6 1.2-.6 2.1 0 .5.1 1 .3 1.5l.3 1.1c.3 1 .7 1.6 1.3 1.6.5 0 1.1-.5 1.8-1.5 1.3-2 2-3.8 2.2-5.4.2-1.9-.3-3.1-1.5-3.6-1.1-.5-2.3-.7-3.6-.7-1.4 0-2.8.4-4.1 1.2-1.3.8-2.5 1.8-3.5 2.9l-1.3 1.4c-.6.7-1.2 1-1.8 1.1-.3 0-.5-.1-.7-.3-.2-.2-.3-.4-.3-.7 0-.4.3-.9.8-1.3.6-.5 1.1-.9 1.4-1.4.4-.5.7-1.1.8-1.8.2-1.1.8-1.9 1.9-2.3C6.4.1 7.4 0 8.5 0c1.3 0 2.4.4 3.4 1.3s1.7 1.9 2.1 3.1c.5 1.3.7 2.6.7 4 0 2.1-.4 3.9-1.2 5.5-.8 1.6-1.9 2.4-3.2 2.4-1.1 0-2.1-.8-2.9-2.3-.9-1.6-1.3-3.2-1.4-4.7-.1-1.3-.1-2.8.2-4.3.3-1.7.9-3.1 1.8-4.2.9-1.1 2-1.6 3.4-1.6 1.1 0 2.1.3 2.8.9.8.6 1.1 1.5 1.1 2.6 0 .5-.1 1-.4 1.6-.3.6-.7.9-1.2.9-.6 0-1.1-.3-1.4-.8-.4-.5-.6-1.2-.6-2.1 0-.5.1-1 .3-1.5l.3-1.1c.3-1 .7-1.6 1.3-1.6.5 0 1.1-.5 1.8-1.5C21.7 8.5 22.4 7 22.6 5c.2-1.9-.3-3.1-1.5-3.6-1.1-.5-2.3-.7-3.6-.7-1.4 0-2.8.4-4.1 1.2-1.3.8-2.5 1.8-3.5 2.9l-1.3 1.4c-.6.7-1.2 1-1.8 1.1-.3 0-.5-.1-.7-.3-.2-.2-.3-.4-.3-.7z"/></svg></a>
    </>
  );

  return (
    <header className="bg-[#FFF9F9]/80 backdrop-blur-md sticky top-0 z-50">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <a href="#home" onClick={handleNavClick} className="flex items-center text-2xl font-serif font-bold text-gray-800 tracking-wider">
          <img 
            src="https://lh3.googleusercontent.com/d/1UUI-boVE95hnNWzQNDrEQdPeHNVhcPsR" 
            alt="Aqsa Shaheen"
            className="w-12 h-12 rounded-full mr-3 border-2 border-red-200 object-cover"
          />
          <span>Aqsa Shaheen</span>
        </a>
        <nav className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={handleNavClick}
              className="text-gray-600 hover:text-accent transition duration-300 border-b-2 border-transparent hover:border-accent pb-1"
            >
              {link.label}
            </a>
          ))}
          <div className="flex items-center space-x-4 pl-4">{socialIcons}</div>
        </nav>
        <div className="md:hidden">
          <button onClick={() => setIsOpen(!isOpen)} className="text-gray-800 focus:outline-none" aria-label="Toggle menu">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              {isOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
              )}
            </svg>
          </button>
        </div>
      </div>
      
      {/* Mobile Menu Panel */}
      <div className={`md:hidden overflow-hidden transition-all duration-300 ease-in-out bg-white ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
        <nav className="flex flex-col items-center space-y-4 py-4 border-t border-red-100">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-gray-600 hover:text-accent transition duration-300"
              onClick={handleNavClick}
            >
              {link.label}
            </a>
          ))}
          <div className="flex items-center space-x-6 pt-4">{socialIcons}</div>
        </nav>
      </div>
    </header>
  );
};

export default Header;