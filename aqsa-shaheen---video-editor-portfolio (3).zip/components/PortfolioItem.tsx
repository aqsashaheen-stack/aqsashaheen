import React from 'react';

interface PortfolioItemProps {
  imgSrc: string;
  title: string;
  category: string;
  videoUrl: string;
  format?: 'long' | 'short';
}

const PlayIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    className={className}
  >
    <path
      fillRule="evenodd"
      d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm14.024-.983a1.125 1.125 0 010 1.966l-5.603 3.113A1.125 1.125 0 019 15.113V8.887c0-.857.921-1.4 1.671-.983l5.603 3.113z"
      clipRule="evenodd"
    />
  </svg>
);


const PortfolioItem: React.FC<PortfolioItemProps> = ({ imgSrc, title, category, videoUrl, format = 'long' }) => {
  const renderLongForm = () => (
    <a
      href={videoUrl}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`View video: ${title}`}
      className="block group relative overflow-hidden rounded-lg cursor-pointer shadow-md"
    >
      <img src={imgSrc} alt={title} className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500" />
      <div className="absolute inset-0 bg-black bg-opacity-20 group-hover:bg-opacity-60 transition-all duration-300 flex items-center justify-center">
        <PlayIcon className="w-16 h-16 text-white opacity-0 group-hover:opacity-100 transform scale-75 group-hover:scale-100 transition-all duration-300" />
      </div>
      <div className="absolute bottom-0 left-0 p-6">
        <p className="text-white text-sm opacity-80 group-hover:opacity-100">{category}</p>
        <h3 className="text-2xl font-bold text-white transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">{title}</h3>
      </div>
    </a>
  );

  const renderShortForm = () => (
    <a
      href={videoUrl}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`View video: ${title}`}
      className="block group cursor-pointer"
    >
      <div className="relative bg-gray-800 p-2 rounded-[24px] shadow-lg transition-transform duration-300 ease-in-out group-hover:-translate-y-2 group-hover:shadow-xl">
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-16 h-4 bg-gray-900 rounded-full z-10"></div>
        <div className="overflow-hidden rounded-[18px] relative">
          <img src={imgSrc} alt={title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
           <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-opacity duration-300 flex items-center justify-center">
             <PlayIcon className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-all duration-300" />
           </div>
        </div>
      </div>
      <div className="text-center mt-3">
        <h3 className="text-md font-bold text-gray-800">{title}</h3>
        <p className="text-sm text-gray-500">{category}</p>
      </div>
    </a>
  );

  return (
    <>
      {format === 'short' ? renderShortForm() : renderLongForm()}
    </>
  );
};

export default PortfolioItem;