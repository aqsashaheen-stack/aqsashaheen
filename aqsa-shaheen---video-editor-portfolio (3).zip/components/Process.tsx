import React from 'react';

const processSteps = [
  {
    step: 1,
    title: 'Consultation & Discovery',
    description: "We start with a detailed discussion to understand your vision, target audience, and project goals. We'll define the style, tone, and key messages.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mb-4 text-accent">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m12 7.5-3-3m0 0l-3 3m3-3v-6m-1.5 9a5.25 5.25 0 10-10.5 0 5.25 5.25 0 0010.5 0z" />
      </svg>
    ),
  },
  {
    step: 2,
    title: 'Footage Organization',
    description: 'You send over your raw footage and assets. I meticulously organize everything, ensuring a smooth and efficient editing workflow from the start.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mb-4 text-accent">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 9.75h16.5m-16.5 4.5h16.5m-16.5 4.5h16.5m-16.5-13.5h16.5a2.25 2.25 0 012.25 2.25v10.5a2.25 2.25 0 01-2.25 2.25H3.75a2.25 2.25 0 01-2.25-2.25V6.5a2.25 2.25 0 012.25-2.25z" />
      </svg>
    ),
  },
  {
    step: 3,
    title: 'First Draft Assembly',
    description: 'I create the initial cut, focusing on building a compelling narrative, setting the right pace, and structuring the story to align with our goals.',
    icon: (
       <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mb-4 text-accent">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.53 16.122a3 3 0 00-5.78 1.128 2.25 2.25 0 01-2.4 2.245 4.5 4.5 0 008.4-2.245c0-.399-.078-.78-.22-1.128zm0 0a15.998 15.998 0 003.388-1.62m-5.043-.025a15.998 15.998 0 011.622-3.385m5.043.025a15.998 15.998 0 001.622-3.385m3.388 1.62a15.998 15.998 0 00-1.622-3.385m-5.043-.025a15.998 15.998 0 01-3.388-1.621m-1.622 3.385a15.998 15.998 0 01-1.622-3.385m5.043.025a15.998 15.998 0 01-1.622 3.385m-3.388-1.62a15.998 15.998 0 013.388 1.62m1.622-3.385a15.998 15.998 0 00-3.388-1.621m-1.622 3.385a15.998 15.998 0 00-1.622 3.385" />
      </svg>
    ),
  },
  {
    step: 4,
    title: 'Revisions & Feedback',
    description: 'The first draft is shared with you for review. We collaborate closely, incorporating your feedback to refine the edit. Two rounds of revisions are included.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mb-4 text-accent">
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.76 9.76 0 01-2.53-.388m-5.168-1.923a8.98 8.98 0 01-.388-2.53c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z" />
      </svg>
    ),
  },
  {
    step: 5,
    title: 'Polishing & Final Touches',
    description: "Once the edit is locked, I add the final magic: color grading, sound design, motion graphics, and any other enhancements to elevate your video.",
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mb-4 text-accent">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.898 20.562L16.25 22.5l-.648-1.938a3.375 3.375 0 00-2.672-2.672L11.25 18l1.938-.648a3.375 3.375 0 002.672-2.672L16.25 13.5l.648 1.938a3.375 3.375 0 002.672 2.672L21.75 18l-1.938.648a3.375 3.375 0 00-2.672 2.672z" />
      </svg>
    ),
  },
  {
    step: 6,
    title: 'Final Delivery',
    description: 'Your polished, high-quality video is delivered in all the required formats, optimized for your chosen platforms and ready to captivate your audience.',
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mb-4 text-accent">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
      </svg>
    ),
  },
];

const Process: React.FC = () => {
  return (
    <section id="process" className="py-20 bg-[#FFF9F9]">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-serif font-bold text-center mb-4 text-gray-900">My Editing Process</h2>
        <p className="text-lg text-gray-600 text-center max-w-3xl mx-auto mb-16">
          A clear and collaborative workflow to bring your vision to life, ensuring quality and efficiency every step of the way.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {processSteps.map((item) => (
            <div key={item.step} className="bg-white p-8 rounded-lg border border-red-100 transition-all duration-300 ease-in-out hover:shadow-xl hover:-translate-y-2">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                    {item.icon}
                </div>
                <div className="ml-5">
                    <h3 className="text-xl font-bold mb-2 text-gray-800">{item.title}</h3>
                    <p className="text-gray-500">{item.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Process;