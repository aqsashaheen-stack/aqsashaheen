import React from 'react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-4xl font-serif font-bold mb-6 text-gray-900">Contact Me</h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
          Looking for a skilled video editor for your next project? I'd love to hear from you. Let's create something amazing together!
        </p>
        <a
          href="https://wa.me/923101562323?text=Hello%2C%20I%27d%20like%20to%20discuss%20a%20video%20editing%20project%20with%20you"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-accent text-white font-bold py-3 px-8 rounded-md hover:bg-red-700 transition duration-300 ease-in-out transform hover:scale-105 inline-block"
        >
          Get In Touch
        </a>
      </div>
    </section>
  );
};

export default Contact;