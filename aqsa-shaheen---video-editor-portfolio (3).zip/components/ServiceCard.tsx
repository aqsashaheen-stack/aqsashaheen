import React from 'react';

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-white p-8 rounded-lg border border-red-100 text-center transition-all duration-300 ease-in-out hover:shadow-xl hover:-translate-y-2">
      {icon}
      <h3 className="text-2xl font-bold mb-3 text-gray-800">{title}</h3>
      <p className="text-gray-500">{description}</p>
    </div>
  );
};

export default ServiceCard;